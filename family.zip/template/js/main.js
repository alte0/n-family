//= ../../bower_components/jQuery/dist/jquery.js
//= ../../bower_components/slick-carousel/slick/slick.js
//= ../../bower_components/letteringjs/jquery.lettering.js
//= ../../bower_components/textillate/jquery.textillate.js
//= ../../bower_components/jquery-modal/jquery.modal.js
//= ../../bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.js
//= ../../bower_components/bootstrap-datepicker/dist/locales/bootstrap-datepicker.ru.min.js

//= parts/code.js
